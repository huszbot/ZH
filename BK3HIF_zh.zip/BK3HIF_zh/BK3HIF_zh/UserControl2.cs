﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BK3HIF_zh
{
    public partial class UserControl2 : UserControl
    {
        Models2.Context2 context = new Models2.Context2();
        public UserControl2()
        {
            InitializeComponent();
        }

        private void UserControl2_Load(object sender, EventArgs e)
        {
            Szallasszuro();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            Szallasszuro();
            Szobaszuro();
            Models2.Szoba szoba = (Models2.Szoba)listBox3.SelectedItem;
            var valasztott = from x in context.Szallashely
                             where x.SzallasId == szoba.SzallasFk
                             select new detaileditem
                             {
                                 SzallasId = x.SzallasId,

                             };
            listBox2.DataSource = valasztott.ToList();
            listBox2.DisplayMember = "SzallasNev";
        }

        private void Szallasszuro()
        {
            var szallasnev = from x in context.Szallashely
                             where x.SzallasNev.Contains(textBox1.Text)
                             select x;
            listBox1.DataSource = szallasnev.ToList();
            listBox1.DisplayMember = "SzallasNev";
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            Szobaszuro();
        }

        private void Szobaszuro()
        {
            var szoba = from x in context.Szoba
                        where x.Ferohely.ToString().Contains(textBox2.Text)
                        select x;
            listBox3.DataSource = szoba.ToList();
            listBox3.DisplayMember = "Ferohely";
        }
    }
}
