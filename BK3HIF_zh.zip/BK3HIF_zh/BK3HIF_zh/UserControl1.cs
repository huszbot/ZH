﻿using BK3HIF_zh.Models2;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BK3HIF_zh
{
    public partial class UserControl1 : UserControl
    {
        new Context2 context = new Context2();

        string[] szobaszam = new string[6] { "1", "2", "3", "4", "5", "6" };
        public UserControl1()
        {
            InitializeComponent();
        }

        private void buttonOk_Click(object sender, EventArgs e)
        {
            Foglalas foglalas = new Foglalas();
            foglalas.SzobaFk = int.Parse(textBoxSzoba.Text);
            foglalas.Mettol = dateTimePickerkezdo.Value;
            foglalas.Meddig = dateTimePickerVeg.Value;
            foglalas.FelnottSzam = int.Parse(textBoxFelnott.Text);
            foglalas.GyermekSzam = int.Parse(textBoxGyerek.Text);

            MessageBox.Show("A foglalás sikeres");
        }

        private void buttonCancel_Click(object sender, EventArgs e)
        {

            DialogResult valami = MessageBox.Show("Biztosan törlöd az adatokat?", "Kilépés", MessageBoxButtons.YesNo);
            if (valami == System.Windows.Forms.DialogResult.Yes)
            {
                textBoxSzoba.Text = String.Empty;
                textBoxFelnott.Text = String.Empty;
                textBoxGyerek.Text = String.Empty;
            }
        }

        private void textBoxSzoba_Validating(object sender, CancelEventArgs e)
        {
            if (Array.IndexOf(szobaszam, textBoxSzoba.Text) == -1)
            {
                e.Cancel = true;
                errorProvider1.SetError(textBoxSzoba, "Adjon meg egy értéket");
            }
        }

        private void textBoxSzoba_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(textBoxSzoba, string.Empty);
        }

        private void textBoxFelnott_Validating(object sender, CancelEventArgs e)
        {
            if (Array.IndexOf(szobaszam, textBoxFelnott.Text) == -1)
            {
                e.Cancel = true;
                errorProvider1.SetError(textBoxFelnott, "Adjon meg egy értéket");
            }
        }

        private void textBoxFelnott_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(textBoxFelnott, string.Empty);
        }
    }
}
