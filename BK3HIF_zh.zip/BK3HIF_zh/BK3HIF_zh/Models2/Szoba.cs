﻿using System;
using System.Collections.Generic;

namespace BK3HIF_zh.Models2;

public partial class Szoba
{
    public int SzobaId { get; set; }

    public string SzobaSzama { get; set; } = null!;

    public int Ferohely { get; set; }

    public int? Potagy { get; set; }

    public string? Klimas { get; set; }

    public int? SzallasFk { get; set; }

    public virtual ICollection<Foglalas> Foglalas { get; } = new List<Foglalas>();

    public virtual Szallashely? SzallasFkNavigation { get; set; }
}
