﻿using System;
using System.Collections.Generic;

namespace BK3HIF_zh.Models2;

public partial class Vendeg
{
    public string Usernev { get; set; } = null!;

    public string Nev { get; set; } = null!;

    public string Email { get; set; } = null!;

    public string? SzamlCim { get; set; }

    public DateTime? SzulDat { get; set; }

    public virtual ICollection<Foglalas> Foglalas { get; } = new List<Foglalas>();
}
