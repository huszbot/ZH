﻿namespace BK3HIF_zh
{
    partial class UserControl1
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.textBoxSzoba = new System.Windows.Forms.TextBox();
            this.textBoxFelnott = new System.Windows.Forms.TextBox();
            this.textBoxGyerek = new System.Windows.Forms.TextBox();
            this.dateTimePickerkezdo = new System.Windows.Forms.DateTimePicker();
            this.dateTimePickerVeg = new System.Windows.Forms.DateTimePicker();
            this.buttonCancel = new System.Windows.Forms.Button();
            this.buttonOk = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.SuspendLayout();
            // 
            // textBoxSzoba
            // 
            this.textBoxSzoba.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxSzoba.Location = new System.Drawing.Point(389, 115);
            this.textBoxSzoba.Name = "textBoxSzoba";
            this.textBoxSzoba.Size = new System.Drawing.Size(114, 23);
            this.textBoxSzoba.TabIndex = 0;
            this.textBoxSzoba.Validating += new System.ComponentModel.CancelEventHandler(this.textBoxSzoba_Validating);
            this.textBoxSzoba.Validated += new System.EventHandler(this.textBoxSzoba_Validated);
            // 
            // textBoxFelnott
            // 
            this.textBoxFelnott.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxFelnott.Location = new System.Drawing.Point(293, 224);
            this.textBoxFelnott.Name = "textBoxFelnott";
            this.textBoxFelnott.Size = new System.Drawing.Size(114, 23);
            this.textBoxFelnott.TabIndex = 1;
            this.textBoxFelnott.Validating += new System.ComponentModel.CancelEventHandler(this.textBoxFelnott_Validating);
            this.textBoxFelnott.Validated += new System.EventHandler(this.textBoxFelnott_Validated);
            // 
            // textBoxGyerek
            // 
            this.textBoxGyerek.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxGyerek.Location = new System.Drawing.Point(483, 224);
            this.textBoxGyerek.Name = "textBoxGyerek";
            this.textBoxGyerek.Size = new System.Drawing.Size(114, 23);
            this.textBoxGyerek.TabIndex = 2;
            // 
            // dateTimePickerkezdo
            // 
            this.dateTimePickerkezdo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.dateTimePickerkezdo.Location = new System.Drawing.Point(270, 175);
            this.dateTimePickerkezdo.Name = "dateTimePickerkezdo";
            this.dateTimePickerkezdo.Size = new System.Drawing.Size(152, 23);
            this.dateTimePickerkezdo.TabIndex = 3;
            // 
            // dateTimePickerVeg
            // 
            this.dateTimePickerVeg.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.dateTimePickerVeg.Location = new System.Drawing.Point(445, 175);
            this.dateTimePickerVeg.Name = "dateTimePickerVeg";
            this.dateTimePickerVeg.Size = new System.Drawing.Size(152, 23);
            this.dateTimePickerVeg.TabIndex = 4;
            // 
            // buttonCancel
            // 
            this.buttonCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonCancel.Location = new System.Drawing.Point(414, 325);
            this.buttonCancel.Name = "buttonCancel";
            this.buttonCancel.Size = new System.Drawing.Size(89, 35);
            this.buttonCancel.TabIndex = 5;
            this.buttonCancel.Text = "Cancel";
            this.buttonCancel.UseVisualStyleBackColor = true;
            this.buttonCancel.Click += new System.EventHandler(this.buttonCancel_Click);
            // 
            // buttonOk
            // 
            this.buttonOk.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonOk.Location = new System.Drawing.Point(532, 325);
            this.buttonOk.Name = "buttonOk";
            this.buttonOk.Size = new System.Drawing.Size(89, 35);
            this.buttonOk.TabIndex = 6;
            this.buttonOk.Text = "Ok";
            this.buttonOk.UseVisualStyleBackColor = true;
            this.buttonOk.Click += new System.EventHandler(this.buttonOk_Click);
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(403, 88);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(92, 15);
            this.label1.TabIndex = 7;
            this.label1.Text = "Hány fős szoba?";
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(293, 206);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(92, 15);
            this.label2.TabIndex = 8;
            this.label2.Text = "Felnőttek száma";
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(483, 206);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(91, 15);
            this.label3.TabIndex = 9;
            this.label3.Text = "Gyerekek száma";
            // 
            // label4
            // 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(270, 157);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(47, 15);
            this.label4.TabIndex = 10;
            this.label4.Text = "Mettől?";
            // 
            // label5
            // 
            this.label5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(445, 157);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(53, 15);
            this.label5.TabIndex = 11;
            this.label5.Text = "Meddig?";
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // UserControl1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.buttonOk);
            this.Controls.Add(this.buttonCancel);
            this.Controls.Add(this.dateTimePickerVeg);
            this.Controls.Add(this.dateTimePickerkezdo);
            this.Controls.Add(this.textBoxGyerek);
            this.Controls.Add(this.textBoxFelnott);
            this.Controls.Add(this.textBoxSzoba);
            this.Name = "UserControl1";
            this.Size = new System.Drawing.Size(677, 387);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private TextBox textBoxSzoba;
        private TextBox textBoxFelnott;
        private TextBox textBoxGyerek;
        private DateTimePicker dateTimePickerkezdo;
        private DateTimePicker dateTimePickerVeg;
        private Button buttonCancel;
        private Button buttonOk;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private ErrorProvider errorProvider1;
    }
}
