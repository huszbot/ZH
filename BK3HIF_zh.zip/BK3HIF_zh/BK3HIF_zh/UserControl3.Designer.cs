﻿namespace BK3HIF_zh
{
    partial class UserControl3
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.szallasIdDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.szallasNevDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.helyDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.csillagokSzamaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tipusDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.rogzitetteDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.rogzIdoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cimDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.szobaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.szallashelyBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.textBox1 = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.szallashelyBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.szallasIdDataGridViewTextBoxColumn,
            this.szallasNevDataGridViewTextBoxColumn,
            this.helyDataGridViewTextBoxColumn,
            this.csillagokSzamaDataGridViewTextBoxColumn,
            this.tipusDataGridViewTextBoxColumn,
            this.rogzitetteDataGridViewTextBoxColumn,
            this.rogzIdoDataGridViewTextBoxColumn,
            this.cimDataGridViewTextBoxColumn,
            this.szobaDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.szallashelyBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(91, 102);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 25;
            this.dataGridView1.Size = new System.Drawing.Size(511, 223);
            this.dataGridView1.TabIndex = 0;
            // 
            // szallasIdDataGridViewTextBoxColumn
            // 
            this.szallasIdDataGridViewTextBoxColumn.DataPropertyName = "SzallasId";
            this.szallasIdDataGridViewTextBoxColumn.HeaderText = "SzallasId";
            this.szallasIdDataGridViewTextBoxColumn.Name = "szallasIdDataGridViewTextBoxColumn";
            // 
            // szallasNevDataGridViewTextBoxColumn
            // 
            this.szallasNevDataGridViewTextBoxColumn.DataPropertyName = "SzallasNev";
            this.szallasNevDataGridViewTextBoxColumn.HeaderText = "SzallasNev";
            this.szallasNevDataGridViewTextBoxColumn.Name = "szallasNevDataGridViewTextBoxColumn";
            // 
            // helyDataGridViewTextBoxColumn
            // 
            this.helyDataGridViewTextBoxColumn.DataPropertyName = "Hely";
            this.helyDataGridViewTextBoxColumn.HeaderText = "Hely";
            this.helyDataGridViewTextBoxColumn.Name = "helyDataGridViewTextBoxColumn";
            // 
            // csillagokSzamaDataGridViewTextBoxColumn
            // 
            this.csillagokSzamaDataGridViewTextBoxColumn.DataPropertyName = "CsillagokSzama";
            this.csillagokSzamaDataGridViewTextBoxColumn.HeaderText = "CsillagokSzama";
            this.csillagokSzamaDataGridViewTextBoxColumn.Name = "csillagokSzamaDataGridViewTextBoxColumn";
            // 
            // tipusDataGridViewTextBoxColumn
            // 
            this.tipusDataGridViewTextBoxColumn.DataPropertyName = "Tipus";
            this.tipusDataGridViewTextBoxColumn.HeaderText = "Tipus";
            this.tipusDataGridViewTextBoxColumn.Name = "tipusDataGridViewTextBoxColumn";
            // 
            // rogzitetteDataGridViewTextBoxColumn
            // 
            this.rogzitetteDataGridViewTextBoxColumn.DataPropertyName = "Rogzitette";
            this.rogzitetteDataGridViewTextBoxColumn.HeaderText = "Rogzitette";
            this.rogzitetteDataGridViewTextBoxColumn.Name = "rogzitetteDataGridViewTextBoxColumn";
            // 
            // rogzIdoDataGridViewTextBoxColumn
            // 
            this.rogzIdoDataGridViewTextBoxColumn.DataPropertyName = "RogzIdo";
            this.rogzIdoDataGridViewTextBoxColumn.HeaderText = "RogzIdo";
            this.rogzIdoDataGridViewTextBoxColumn.Name = "rogzIdoDataGridViewTextBoxColumn";
            // 
            // cimDataGridViewTextBoxColumn
            // 
            this.cimDataGridViewTextBoxColumn.DataPropertyName = "Cim";
            this.cimDataGridViewTextBoxColumn.HeaderText = "Cim";
            this.cimDataGridViewTextBoxColumn.Name = "cimDataGridViewTextBoxColumn";
            // 
            // szobaDataGridViewTextBoxColumn
            // 
            this.szobaDataGridViewTextBoxColumn.DataPropertyName = "Szoba";
            this.szobaDataGridViewTextBoxColumn.HeaderText = "Szoba";
            this.szobaDataGridViewTextBoxColumn.Name = "szobaDataGridViewTextBoxColumn";
            this.szobaDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // szallashelyBindingSource
            // 
            this.szallashelyBindingSource.DataSource = typeof(BK3HIF_zh.Models2.Szallashely);
            // 
            // textBox1
            // 
            this.textBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox1.Location = new System.Drawing.Point(290, 63);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 23);
            this.textBox1.TabIndex = 1;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // UserControl3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Highlight;
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.dataGridView1);
            this.Name = "UserControl3";
            this.Size = new System.Drawing.Size(703, 341);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.szallashelyBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DataGridView dataGridView1;
        private DataGridViewTextBoxColumn szallasIdDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn szallasNevDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn helyDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn csillagokSzamaDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn tipusDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn rogzitetteDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn rogzIdoDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn cimDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn szobaDataGridViewTextBoxColumn;
        private BindingSource szallashelyBindingSource;
        private TextBox textBox1;
    }
}
