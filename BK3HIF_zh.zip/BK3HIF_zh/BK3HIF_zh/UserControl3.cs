﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BK3HIF_zh
{
    public partial class UserControl3 : UserControl
    {
        Models2.Context2 context = new Models2.Context2();
        public UserControl3()
        {
            InitializeComponent();
            helykereso();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            helykereso();
        }

        private void helykereso()
        {
            var hely = from x in context.Szallashely
                       where x.Hely.Contains(textBox1.Text)
                       select x;
            dataGridView1.DataSource = hely.ToList();
        }
    }
}
