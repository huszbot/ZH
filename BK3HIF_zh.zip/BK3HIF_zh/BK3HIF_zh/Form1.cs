namespace BK3HIF_zh
{
    public partial class Form1 : Form
    {
        UserControl1 u1 = new UserControl1();
        UserControl2 u2 = new UserControl2();
        UserControl3 u3 = new UserControl3();
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            u3.Hide();
            u2.Hide();
            u1.Show();

            u1.Dock = DockStyle.Fill;
            this.Controls.Add(u1);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            u3.Hide();
            u2.Show();
            u1.Hide();

            u2.Dock = DockStyle.Fill;
            this.Controls.Add(u2);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            u3.Show();
            u2.Hide();
            u1.Hide();

            u3.Dock = DockStyle.Fill;
            this.Controls.Add(u3);
        }
    }
}